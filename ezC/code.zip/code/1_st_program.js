// the hello world program

function fToC()
{
  var deg_c, deg_c;

  deg_f = parseInt(document.getElementById("farenheit").value);
  deg_c = Math.round(100*5*(deg_f-32)/9.0)/100;
  document.getElementById("answer").value = deg_c;
}




