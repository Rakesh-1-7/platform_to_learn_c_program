
function fToC()
{


	str = document.getElementById("string").value;
	str_cpy = str;
	i = str.length;

	


  document.getElementById("answer").innerHTML = "The copied string is : "+str_cpy+"<br>Length of the string is : "+i;
  
}











